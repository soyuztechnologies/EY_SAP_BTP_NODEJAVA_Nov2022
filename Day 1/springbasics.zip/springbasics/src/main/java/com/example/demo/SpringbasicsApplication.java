package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.classes.Airplane;

@SpringBootApplication
public class SpringbasicsApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(SpringbasicsApplication.class, args);
		
		Airplane plane1 = context.getBean(Airplane.class);
		
		System.out.println(plane1.fly());
		
	}

}
