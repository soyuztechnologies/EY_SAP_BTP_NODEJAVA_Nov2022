package com.example.demo.classes;

public interface IWing {
	@Override
	public String toString();
}
