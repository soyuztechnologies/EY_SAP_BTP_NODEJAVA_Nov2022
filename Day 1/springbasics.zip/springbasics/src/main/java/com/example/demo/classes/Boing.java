package com.example.demo.classes;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class Boing implements IWing {
	
	private String WingName;

	public Boing() {
		super();
		WingName = "Boing Wing";
	}

	@Override
	public String toString() {
		return "Boing [WingName=" + WingName + ", toString()=" + super.toString() + "]";
	}
	
	
	
}
