package com.example.demo.classes;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component

public class Airbus implements IWing {
	private String WingName;

	public Airbus() {
		super();
		WingName = "Airbus Wing";
	}

	@Override
	public String toString() {
		return "Airbus [WingName=" + WingName + ", toString()=" + super.toString() + "]";
	}
}
