package com.example.demo.classes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Airplane {
	
	@Autowired
	private IWing wing;
	private int planeId;
	private String Airline;
	private String FlightType;
	
	public int getPlaneId() {
		return planeId;
	}
	public void setPlaneId(int planeId) {
		this.planeId = planeId;
	}
	public String getAirline() {
		return Airline;
	}
	public void setAirline(String airline) {
		Airline = airline;
	}
	public String getFlightType() {
		return FlightType;
	}
	public void setFlightType(String flightType) {
		FlightType = flightType;
	}
	
	public Airplane() {
		System.out.println("Plane object was created");
	}
	
	public String fly() {
		System.out.println(wing.toString());
		return "My plane is flying now";
	}
	
	
	
}
